# 🏘️ Realitný Agregátor — Nitra Region MVP

Automated real estate aggregator and analytical dashboard for the Nitra district (Nitriansky kraj).
Detects **investment anomalies** — properties priced ≥20% below the clean segment median.

---

## Architecture

```
realty_aggregator/
├── app.py                  # Streamlit dashboard (main entry point)
├── models.py               # SQLAlchemy DB models (Listing, PriceHistory)
├── seed_demo.py            # Demo data seeder (~120 realistic SK listings)
├── run_scrapers.py         # CLI scraper runner
├── requirements.txt
├── data/
│   └── realty.db           # SQLite database (auto-created)
├── utils/
│   └── engine.py           # Deduplication + Math analytics engine
└── scrapers/
    ├── base.py             # Abstract base with rotating user-agents
    ├── nehnutelnosti.py    # Nehnutelnosti.sk scraper skeleton
    └── bazos.py            # Bazos.sk scraper skeleton
```

---

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Seed with demo data (120 realistic Nitra-region listings)
python seed_demo.py

# 3. Launch dashboard
streamlit run app.py
```

---

## Mathematical Specification

### Hot Deal Detection Formula

$$P_{sqm} \leq 0.80 \times \widetilde{P}_{segment}$$

Where:
- $P_{sqm}$ = price per m² of a specific listing
- $\widetilde{P}_{segment}$ = **IQR-cleaned median** price per m² in the micro-segment

### Outlier Removal (IQR Method)

Before computing the segment median, Tukey fences are applied:

$$\text{lower} = Q_1 - 1.5 \times IQR$$
$$\text{upper} = Q_3 + 1.5 \times IQR$$

Listings outside these fences are **excluded from the median calculation only** (they remain in the DB).

### Deduplication Logic

A listing is merged with an existing record if ALL of the following match:
- `location_city` — exact match (case-insensitive)
- `property_type` — exact match
- `area_sqm` — within ±2% relative tolerance
- `absolute_price` — within ±2% relative tolerance

On merge: the new source URL is appended, and a `PriceHistory` record is created if the price changed.

### Micro-Segment Definition

Grouping key: `(location_city, property_type)`

A segment requires **≥3 listings** to compute a valid median.

---

## Running Scrapers

```bash
# Run all scrapers
python run_scrapers.py

# Run specific scraper
python run_scrapers.py --scraper bazos
python run_scrapers.py --scraper nehnutelnosti

# Dry run (parse without saving)
python run_scrapers.py --dry-run
```

> **Note:** The scrapers are structural skeletons with realistic CSS selectors.
> Adjust selectors in `scrapers/nehnutelnosti.py` and `scrapers/bazos.py`
> if the portals update their markup.

---

## Dashboard Views

| Tab | Description |
|-----|-------------|
| 📋 Všetky inzeráty | Filterable table of all active listings + note editor + price history |
| 🔥 Hot Deals | Mathematically verified anomalies with bar chart comparison |
| 📈 Analytika | Box plots, city distribution, price vs. area scatter |

### Filters (sidebar)
- City / Municipality
- Property type (multi-select)
- Price range slider
- Area range slider  
- Full-text search

---

## Database Schema

### `listings`
| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| source_urls | TEXT (JSON) | Array of portal URLs |
| location_city | VARCHAR | |
| location_district | VARCHAR | e.g. "Chrenová" |
| property_type | ENUM | byt/dom/pozemok/komercia/iny |
| subtype | VARCHAR | e.g. "3-izbový byt" |
| condition | VARCHAR | e.g. "pôvodný stav" |
| area_sqm | FLOAT | |
| absolute_price | FLOAT | EUR |
| price_per_sqm | FLOAT | Computed on insert |
| status | ENUM | active/inactive |
| internal_notes | TEXT | Editable from UI |
| created_at / updated_at | DATETIME | |

### `price_history`
| Column | Type | Notes |
|--------|------|-------|
| id | INTEGER PK | |
| listing_id | INTEGER FK | |
| old_price / new_price | FLOAT | |
| old_price_per_sqm / new_price_per_sqm | FLOAT | |
| changed_at | DATETIME | |
| note | VARCHAR | Reason for change |
